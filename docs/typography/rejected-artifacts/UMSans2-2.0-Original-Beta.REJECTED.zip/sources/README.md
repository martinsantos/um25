# UM Sans 2.0 Original Beta sources

These UFO masters, designspaces and feature sources are generated exclusively from the geometric constructions in `scripts/fonts/build_um_sans_2.py`. The builder does not open, subset or transform Inter or another font.

The release contains 14 boolean-cleaned static styles. Designspaces are included as source documentation; variable binaries are intentionally blocked until the cleaned masters pass contour-compatibility review. The family remains a beta until independent similarity, trademark, authorship and platform reviews are signed.
